const fs = require('fs');
const path = require('path');
const usersPath = './registered_users.json';
const imagesDir = './images';

// قائمة الـ 500 شخصية لفعالية "الكتابة" فقط
const writingAnimeList = [
    "لوفي", "زورو", "سانجي", "ايس", "سابو", "كيد", "ناروتو", "ساسكي", "سارادا", "بوروتو",
    "جين", "ميرويم", "غون", "كيلوا", "غوهان", "بيكولو", "فريزا", "سيل", "بيروس", "ايتادوري",
    "يوجي", "غوجو", "ساتورو", "سوكونا", "ميغومي", "توجي", "كيو", "زينيتسو", "تانجيرو", "اينوسكي",
    "نيزوكو", "غيو", "دوما", "شينوبو", "كاناو", "كاناي", "رينغوكو", "تنغن", "ابوياشيكي", "كاغايا",
    "بياكويا", "مادارا", "ايتاشي", "سونغ", "بارك", "دانيال", "غان", "غو", "فو", "شو",
    "ال", "اي", "تو", "كي", "بي", "رين", "ريو", "ايساغي", "كاراسو", "ايغو",
    "نوا", "رافينهو", "ناغي", "باتشيرا", "ساي", "هوغو", "لوكي", "باني", "زينين", "زينو",
    "دانتي", "سيلفا", "استا", "يونو", "يامي", "ويليام", "يوليوس", "فانيكا", "فانيسا", "غوثر",
    "غوش", "فريلند", "لاك", "راغنا", "فويغوليون", "ميرليونا", "ليوبولد", "نويل", "نوزيل", "لوسيفر",
    "جلجاميش", "اوراهارا", "ايتشيغو", "اينوي", "ايشيدا", "كون", "يوريتشي", "نامي", "يوسوب",
    "تشوبر", "روبين", "فرانكي", "بروك", "جينبي", "شانكس", "باهغي", "ميهوك", "سموكر", "كروكودايل",
    "اينيل", "دوفلامينغو", "كاتاكوري", "كابوتو", "جرايا", "تسونادي", "اوروتشيمارو", "شيكامارو", "تشوجي", "كيبا",
    "شينو", "غارا", "كانكورو", "تيماري", "ميناتو", "كوشينا", "كارين", "سويغيتسو", "جوغو", "اوبيتو",
    "كيسامي", "ساسوري", "ديدارا", "كاكوزو", "هيدان", "باين", "كونان", "زيتسو", "كوراما", "ميكاسا",
    "ارمين", "ليفاي", "اروين", "هانجي", "جان", "كوني", "ساشا", "راينر", "بيرتولت", "اندريه",
    "زيك", "فالكو", "غابي", "يلينا", "بيكسيس", "جريشا", "كارلا", "ديو", "جوتارو", "جوسكي",
    "جوليان", "كيريتو", "ين", "يوي", "كلاين", "ايغدراسيل", "كوراساكي", "رينجي", "روكيا", "جريمجو",
    "اولكيورا", "ايزن", "توشيرو", "كينباتشي", "كومامورا", "مايوري", "ياماموتو", "جينشي", "سويفون", "ايتشيرو",
    "تسونا", "غوكوديرا", "ياماموتو", "موكورو", "كيويا", "رانبو", "دازاي", "اتسوشي", "كونيكيدا", "اكوتاغاوا",
    "تشويا", "فيودور", "نيكولاي", "موراي", "تانيزاكي", "كينجي", "فوكوزاوا", "اوداساكو", "كيوكا", "يوسانو",
    "تومورا", "دابي", "توغا", "شيغاراكي", "باكوغو", "ميدوريا", "تودوروكي", "ايزاوا", "اولمايت", "هوكس", "انديفور",
    "كاميناري", "كيريشيما", "اييدا", "اوراراكا", "اسوي", "جيرو", "توكويامي", "ايرو", "نينو", "ميكو",
    "يوتسوبا", "ايتسوكي", "ايتشيكا", "سوبارو", "إميليا", "ريم", "رام", "بياتريس", "روسوال", "غارفيل",
    "اوتو", "اكيدنا", "فلت", "راينهارد", "ويلهلم", "بتلغوس", "سينشي", "كونان", "ران", "كايتو",
    "هيجي", "كازوها", "سونوكو", "سيرا", "امورو", "اكاي", "جين", "فودكا", "فيرموث", "بوربون",
    "شيري", "ايومي", "ميتسوهيكو", "جينتا", "اغاسا", "سوبارو", "اكامي", "تاتسومي", "ماين", "شيل",
    "ليوني", "لوبوك", "بولات", "ايسديث", "كورومي", "وايف", "ران", "سيريو", "بورس", "تشيلسي",
    "سيتاما", "جينوس", "غارو", "تاتسوماكي", "فوبوكي", "بانغ", "كينغ", "اتوميك", "زومبي", "درايف",
    "بليزارد", "سونيك", "سيتشوان", "موموجي", "تانغي", "هاشيبيرا", "رينغوكو", "سانيمي", "اوباناي", "ميتسوري",
    "غيومي", "مويتشيرو", "توشيكازو", "ماكيو", "سوما", "هيناوا", "تامايو", "يوشيرو", "موزان", "كوكوشيبو",
    "أكازا", "غيوكوكو", "هانتنغو", "غيوتارو", "داكي", "كاغايا", "ساكونجي", "جيرو", "سبايك", "جيت",
    "فاين", "فاي", "أدوارد", "فينسينت", "فانيسا", "ميرلين", "كينغ", "ديان", "اسكانور", "غاوثر",
    "ميليوداس", "الي his", "مونديك", "غيلثندر", "هاوزر", "دريتوس", "هيندريكسون", "ارثر", "زايلدريس", "استاروسا",
    "مونسبليت", "دريري", "غالاند", "ملدريس", "غرايرود", "فرودرين", "ميراسكيلا", "دولور", "غلوكسينيا", "تشارلز",
    "لايت", "ريوك", "ميزا", "نير", "ميلو", "مات", "واتاري", "ريم", "ماسامونا", "اماني",
    "ماساشي", "كاتسورا", "تاكاسوجي", "ساكاموتو", "كوندو", "هيجيشكاتا", "اوكيتا", "شينباتشي", "كاغورا", "ساداهارو",
    "اليثabeth", "شينسوكي", "كاموي", "ابوتو", "تسوكويو", "نوبوميث", "توشيرو", "شينغين", "مايومامي", "كوهين",
    "اينوياشا", "كاغومي", "شيبو", "ميروكو", "سانغو", "كيكيو", "سيشومارو", "جاكن", "كوهين", "ناراكو", "كاناي",
    "كوراغاني", "كوران", "يوكي", "زيرو", "كانامي", "ايدو", "شيكي", "ايشيرو", "تودو", "روكا",
    "رين", "يوكيمورا", "ماساموني", "سانادا", "شينا", "كوجيرو", "موساشي", "شينغين", "كنشين", "سانوسكي",
    "سايتو", "كاورو", "ياهيكو", "ميوشين", "شيشيو", "سوجيرو", "انيوا", "تسوبامي", "رايكو", "كوري",
    "سينغوكو", "غارب", "تسورو", "اوكيجي", "كيزارو", "اكاينو", "فوجيتورا", "ريوكوغيو", "كوبي", "هيلميبو",
    "سموكر", "تاشيجي", "هينا", "جانجوا", "فولبودي", "مومونوسكي", "كينيمون", "رايزو", "كانجورو", "اشورا",
    "دينجيرو", "كاواشوماتسو", "كيكو", "إيزو", "ياماتو", "هيوري", "تاما", "سوكياكي", "ياسوي", "رودريك",
    "نورمان", "راي", "إيما", "دون", "جيلدا", "فيل", "إيزابيلا", "كرستينا", "كرونا", "سونجو", "مجيكا",
    "فاني", "كلود", "يولوس", "نوا", "فانيسا", "شارلوت", "روبيل", "غيلدر", "زاكس", "جاك",
    "ناشاد", "رينولدز", "كيلفين", "مارتن", "ميرلين", "سيرجيو", "الفونسو", "كارلوس", "هيكتور", "دييغو",
    "روي", "ادواراد", "الفونس", "وينري", "موستنغ", "هاوكاي", "ارمسترونغ", "هيوز", "لينغ", "ماتياس",
    "لانج", "ماي", "سكار", "برادلي", "انفي", "لوست", "غيدون", "سلوث", "جيد", "هوهنهايم"
];

// القائمة المختصرة لفعاليات (تفكيك، ترتيب، تركيب، عكس)
const otherAnimeList = [
    "لوفي", "زورو", "سانجي", "ايس", "سابو", "كيد", "ناروتو", "ساسكي", "سارادا", "بوروتو",
    "جين", "ميرويم", "غون", "كيلوا", "غوهان", "بيكولو", "فريزا", "سيل", "بيروس", "ايتادوري",
    "يوجي", "غوجو", "ساتورو", "سوكونا", "ميغومي", "توجي", "كيو", "زينيتسو", "تانجيرو", "اينوسكي",
    "نيزوكو", "غيو", "دوما", "شينوبو", "كاناو", "كاناي", "رينغوكو", "تنغن", "ابوياشيكي", "كاغايا",
    "بياكويا", "مادارا", "ايتاشي", "سونغ", "بارك", "دانيال", "غان", "غو", "فو", "شو",
    "ال", "اي", "تو", "كي", "بي", "رين", "ريو", "ايساغي", "كاراسو", "ايغو",
    "نوا", "رافينهو", "ناغي", "باتشيرا", "ساي", "هوغو", "لوكي", "باني", "زينين", "زينو",
    "دانتي", "سيلفا", "استا", "يونو", "يامي", "ويليام", "يوليوس", "فانيكا", "فانيسا", "غوثر",
    "غوش", "فريلند", "لاك", "راغنا", "فويغوليون", "ميرليونا", "ليوبولد", "نويل", "نوزيل", "لوسيفر",
    "جلجاميش", "اوراهارا", "ايتشيغو", "اينوي", "ايشيدا", "كون", "يوريتشي", "نامي", "يوسوب",
    "تشوبر", "روبين", "فرانكي", "بروك", "جيمبي", "شانكس", "باغي", "ميهوك", "سموكر", "كروكودايل",
    "اينيل", "دوفلامينغو", "كاتاكوري", "كابوتو"
];

const questionsList = [
    { q: "سيف روجر؟", a: ["ايس"] },
    { q: "اقوى سياف؟", a: ["ميهوك"] },
    { q: "الهوكاجي6؟", a: ["كاكاشي", "هاتاكي"] },
    { q: "عراب الحريه؟", a: ["ايرين"] },
    { q: "بطل البحرية؟", a: ["غارب", "جارب"] },
    { q: "عائلة كيلوا؟", a: ["زولديك"] },
    { q: "كيرا؟", a: ["لايت"] },
    { q: "زيرو؟", a: ["لولوش"] },
    { q: "صائد الابطال؟", a: ["غارو", "جارو"] },
    { q: "قباعة القش؟", a: ["لوفي"] },
    { q: "قاتل ايس؟", a: ["اكاينو"] },
    { q: "صائد القراصنة؟", a: ["زورو"] },
    { q: "الكيوبي؟", a: ["كوراما"] },
    { q: "قاتل جيرايا؟", a: ["باين"] },
    { q: "اخو ايتاشي؟", a: ["ساسكي"] },
    { q: "قاتل اللحية البيضاء؟", a: ["تيتش"] },
    { q: "ملك القراصنة؟", a: ["روجر"] },
    { q: "اقوى مخلوق؟", a: ["كايدو"] },
    { q: "عرق جيمبي؟", a: ["يوجين"] },
    { q: "فاكهة تشوبر؟", a: ["انسان"] },
    { q: "افضل محقق؟", a: ["ال"] },
    { q: "خليفة ال؟", a: ["نير"] },
    { q: "خطائه الغضب؟", a: ["ميليوداس"] },
    { q: "حاكم بريطانيا؟", a: ["لولوش"] },
    { q: "اخو ادوارد؟", a: ["الفونس"] },
    { q: "قط ناتسو؟", a: ["هابي"] },
    { q: "العملاق العربه؟", a: ["بيك"] },
    { q: "العملاق المدرع؟", a: ["راينر"] },
    { q: "العملاق الضخم؟", a: ["ارمين"] },
    { q: "الثوري الثاني ؟", a: ["سابو"] },
    { q: "صاحب فاكهة ميرا ميرا؟", a: ["سابو"] },
    { q: "اسم لي الاول؟", a: ["روك"] },
    { q: "اسم فانجانس الاول؟", a: ["ويليام"] },
    { q: "شارلوك .......؟", a: ["هومز"] },
    { q: "جاك .......؟", a: ["السفاح"] },
    { q: "موحد الصين؟", a: ["ايسي"] },
    { q: "زوجة غوكو؟", a: ["تشي تشي"] },
    { q: "حاكم الكون 7؟", a: ["بيروس"] },
    { q: "مستر برنس؟", a: ["سانجي"] },
    { q: "تلميذه تسونادي؟", a: ["ساكورا"] },
    { q: "الرصاصة الفضية؟", a: ["اكاي"] },
    { q: "ابنة موري ؟", a: ["ران"] },
    { q: "وميض كونوها؟", a: ["ميناتو"] },
    { q: "الاسد الذهبي؟", a: ["شيكي"] },
    { q: "مربية لوفي؟", a: ["دادان"] },
    { q: "امير السايان؟", a: ["فيجيتا"] },
    { q: "الساق السوداء؟", a: ["سانجي"] },
    { q: "القرد الاصفر؟", a: ["كيزارو"] },
    { q: "الساق الحمراء؟", a: ["زيف"] },
    { q: "قائد العناكب؟", a: ["كرولو"] },
    { q: "ابن اوسين؟", a: ["اوهون"] },
    { q: "اخطر رجل؟", a: ["دراغون"] },
    { q: "المتحكم في باين؟", a: ["ناغاتو"] },
    { q: "هاشيرا الرياح؟", a: ["سانيمي"] },
    { q: "والد ثورفين؟", a: ["ثورز"] },
    { q: "ام ايس؟", a: ["روج"] },
    { q: "ملك الظلام؟", a: ["رايلي"] },
    { q: "ملك الظلال؟", a: ["سونغ"] },
    { q: "ام ناروتو؟", a: ["كوشينا"] },
    { q: "رجل المنشار؟", a: ["دينجي"] },
    { q: "اخت نامي؟", a: ["نوجيكو"] },
    { q: "خطيئة الكبرياء؟", a: ["اسكانور"] },
    { q: "ملك اللعنات؟", a: ["سوكونا"] },
    { q: "الشيطان الابيض؟", a: ["جينتوكي"] },
    { q: "رقم هيسوكا؟", a: ["44", "٤٤"] },
    { q: "حبيبة بان؟", a: ["ايلين"] },
    { q: "نائب كايدو؟", a: ["كينغ", "كينج"] },
    { q: "نصف غول؟", a: ["كانيكي", "كين"] },
    { q: "قائد المعجزات؟", a: ["اكاشي"] },
    { q: "ملك الوحوش؟", a: ["كايدو"] },
    { q: "كلب الحمم؟", a: ["اكاينو"] },
    { q: "الرقم ثنين؟", a: ["هوكس"] },
    { q: "اقوى شامان؟", a: ["غوجو"] },
    { q: "اقوى مستخدم نين؟", a: ["نيترو", "نيتيرو"] },
    { q: "ملك النمل؟", a: ["ميرويم"] },
    { q: "ابن البحر؟", a: ["جيمبي", "جينبي"] },
    { q: "زوجت لويد؟", a: ["يور"] },
    { q: "بديل ساسكي؟", a: ["ساي"] },
    { q: "بنت ساسكي؟", a: ["سارادا"] },
    { q: "قاطع الرؤوس؟", a: ["كانكي"] },
    { q: "المحقق النائم؟", a: ["موري"] },
    { q: "نائب لاو؟", a: ["بيبو"] },
    { q: "ابن دراغون؟", a: ["لوفي"] },
    { q: "عين الصقر؟", a: ["ميهوك"] },
    { q: "حبيبة كانيكي؟", a: ["توكا"] },
    { q: "شينيغامي لايت؟", a: ["ريوك"] },
    { q: "تلميذ غاي؟", a: ["لي", "روك"] },
    { q: "ابنة شانكس؟", a: ["اوتا"] },
    { q: "وعاء سوكونا؟", a: ["يوجي", "ايتادوري"] },
    { q: "قاتل كايتو؟", a: ["بيتو"] },
    { q: "طائر تشين؟", a: ["اوكي"] },
    { q: "كلب ماكيما؟", a: ["دينجي"] },
    { q: "اخ شينرا؟", a: ["شو"] },
    { q: "السياف الاسود؟", a: ["غاتس"] }
];

let pools = {
    writing: [],
    otherWords: [],
    questions: [],
    images: []
};

const defaultTypes = ['كتابة', 'تفكيك', 'صور', 'ترتيب', 'اسئله', 'تركيب', 'عكس'];

let gameState = {
    active: false,
    paused: false,
    targetPoints: 0,
    chatId: null,
    scores: {},
    activeTypes: [...defaultTypes],
    currentTypeIndex: 0,
    typeRound: 1,
    currentWord: '',
    validAnswers: [],
    currentType: '',
    roundTimer: null,
    acceptingAnswers: false
};

const sleep = ms => new Promise(res => setTimeout(res, ms));

function shuffleString(str) {
    let a = str.split(''), n = a.length;
    for (let i = n - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        let tmp = a[i]; a[i] = a[j]; a[j] = tmp;
    }
    return a.join(' ');
}

function getFormattedUser(rawJid) {
    const users = fs.existsSync(usersPath) ? JSON.parse(fs.readFileSync(usersPath, 'utf8')) : {};
    const cleanJid = rawJid.split('@')[0].split(':')[0];

    const matchedKey = Object.keys(users).find(key => {
        const cleanKey = key.split('@')[0].split(':')[0];
        return key === rawJid || cleanKey === cleanJid;
    });

    if (matchedKey && users[matchedKey]) {
        return { text: users[matchedKey], isMention: false };
    } else {
        return { text: `@${cleanJid}`, isMention: true, jid: rawJid };
    }
}

function checkAnswer(userText, validAnswers, currentType) {
    if (currentType === 'تفكيك') {
        const chars = userText.trim().split(/[^\u0621-\u064A]+/).filter(Boolean);

        return validAnswers.some(ans => {
            const cleanTargetChars = ans.replace(/[^\u0621-\u064A]/g, '').split('');
            if (chars.length !== cleanTargetChars.length) return false;

            const allSingleChars = chars.every(c => c.length === 1);
            if (!allSingleChars) return false;

            return chars.join('') === cleanTargetChars.join('');
        });
    } else {
        const cleanedText = userText.replace(/[^\u0621-\u064A\s]/g, ' ').replace(/\s+/g, ' ').trim();
        const userWords = cleanedText.split(' ');

        return validAnswers.some(ans => {
            const cleanAns = ans.trim();
            const ansWords = cleanAns.split(' ');

            if (ansWords.length === 1) {
                return userWords.includes(ansWords[0]);
            } else {
                return cleanedText.includes(cleanAns);
            }
        });
    }
}

async function nextRound(sock) {
    if (!gameState.active || gameState.paused) return;

    if (gameState.roundTimer) clearTimeout(gameState.roundTimer);
    gameState.acceptingAnswers = false;

    try {
        const typesToUse = (gameState.activeTypes && gameState.activeTypes.length > 0) ? gameState.activeTypes : defaultTypes;
        const currentType = typesToUse[gameState.currentTypeIndex % typesToUse.length];
        gameState.currentType = currentType;

        if (gameState.typeRound === 1) {
            await sock.sendMessage(gameState.chatId, { text: `*${currentType} استعدو*` });
            await sleep(1000);
        }

        await sock.sendMessage(gameState.chatId, { text: '*3 2 1*' });
        await sleep(1000);

        if (currentType === 'صور') {
            if (!fs.existsSync(imagesDir)) {
                advanceType();
                return nextRound(sock);
            }

            if (pools.images.length === 0) {
                pools.images = fs.readdirSync(imagesDir).filter(f => f.endsWith('.jpg') || f.endsWith('.png') || f.endsWith('.jpeg') || f.endsWith('.gif'));
            }

            if (pools.images.length === 0) {
                advanceType();
                return nextRound(sock);
            }

            const randomIndex = Math.floor(Math.random() * pools.images.length);
            const selectedFile = pools.images.splice(randomIndex, 1)[0];

            const fileNameWithoutExt = path.parse(selectedFile).name;
            const rawAnswers = fileNameWithoutExt.split(/\s+او\s+/);
            gameState.validAnswers = rawAnswers.map(a => a.trim());

            const imagePath = path.join(imagesDir, selectedFile);
            const imageBuffer = fs.readFileSync(imagePath);

            await sock.sendMessage(gameState.chatId, {
                image: imageBuffer,
                caption: `*صور ${gameState.typeRound}*`
            });

        } else if (currentType === 'اسئله') {
            if (pools.questions.length === 0) {
                pools.questions = [...questionsList];
            }

            const randomIndex = Math.floor(Math.random() * pools.questions.length);
            const randomItem = pools.questions.splice(randomIndex, 1)[0];
            gameState.validAnswers = randomItem.a;

            await sock.sendMessage(gameState.chatId, {
                text: `*اسئله ${gameState.typeRound}*\n\n*${randomItem.q}*`
            });

        } else {
            let word = '';

            if (currentType === 'كتابة') {
                if (pools.writing.length === 0) {
                    pools.writing = [...writingAnimeList];
                }
                const randomIndex = Math.floor(Math.random() * pools.writing.length);
                word = pools.writing.splice(randomIndex, 1)[0];
            } else {
                if (pools.otherWords.length === 0) {
                    pools.otherWords = [...otherAnimeList];
                }
                const randomIndex = Math.floor(Math.random() * pools.otherWords.length);
                word = pools.otherWords.splice(randomIndex, 1)[0];
            }

            gameState.currentWord = word;

            let promptText = '';
            let answer = '';

            switch (currentType) {
                case 'كتابة':
                    promptText = word;
                    answer = word;
                    break;
                case 'تفكيك':
                    promptText = word;
                    answer = word.split('').join(' ');
                    break;
                case 'ترتيب':
                    let shuffled = shuffleString(word);
                    while (shuffled.replace(/ /g, '') === word && word.length > 1) {
                        shuffled = shuffleString(word);
                    }
                    promptText = shuffled;
                    answer = word;
                    break;
                case 'تركيب':
                    promptText = word.split('').join(' ');
                    answer = word;
                    break;
                case 'عكس':
                    promptText = word;
                    answer = word.split('').reverse().join('');
                    break;
            }

            gameState.validAnswers = [answer];

            await sock.sendMessage(gameState.chatId, {
                text: `*${currentType} ${gameState.typeRound}*\n\n*${promptText}*`
            });
        }

        gameState.acceptingAnswers = true;

        gameState.roundTimer = setTimeout(async () => {
            if (!gameState.active || gameState.paused || !gameState.acceptingAnswers) return;
            gameState.acceptingAnswers = false;

            try {
                await sock.sendMessage(gameState.chatId, { text: 'تم إلغاء الجولة' });
                await sleep(500);
                advanceType();
                nextRound(sock);
            } catch (err) {
                console.error("خطأ شبكة أثناء إلغاء الجولة، تم إيقاف الفعالية مؤقتاً:", err);
                gameState.paused = true;
            }
        }, 10000);

    } catch (error) {
        console.error("حدث خطأ في الاتصال، تم إيقاف الفعالية مؤقتاً لحماية التيرمكس:", error);
        gameState.paused = true; // توقيف الفعالية تلقائياً عند انقطاع النت بدلاً من كرش السيرفر
    }
}

function advanceType() {
    gameState.typeRound++;
    if (gameState.typeRound > 5) {
        gameState.typeRound = 1;
        const typesToUse = (gameState.activeTypes && gameState.activeTypes.length > 0) ? gameState.activeTypes : defaultTypes;
        gameState.currentTypeIndex = (gameState.currentTypeIndex + 1) % typesToUse.length;
    }
}

module.exports = {
    gameState,
    sleep,
    getFormattedUser,
    checkAnswer,
    nextRound,
    advanceType,
    defaultTypes
};
